def quick_sort(arr):
    steps = []
    comparisons = 0
    swaps = 0
    a = arr.copy()

    def record(kind, indices, message):
        steps.append({
            "type": kind,
            "indices": indices,
            "array": a.copy(),
            "message": message
        })

    def partition(low, high):
        nonlocal comparisons, swaps
        pivot = a[high]
        i = low - 1

        for j in range(low, high):
            comparisons += 1
            record("compare", [j, high], f"Compare {a[j]} with pivot {pivot}")
            if a[j] <= pivot:
                i += 1
                if i != j:
                    a[i], a[j] = a[j], a[i]
                    swaps += 1
                    record("swap", [i, j], f"Swap {a[i]} and {a[j]}")

        if i + 1 != high:
            a[i + 1], a[high] = a[high], a[i + 1]
            swaps += 1
            record("swap", [i + 1, high], f"Place pivot {pivot} at index {i + 1}")

        return i + 1

    def sort(low, high):
        if low < high:
            pivot_index = partition(low, high)
            record("pivot", [pivot_index], f"Pivot {a[pivot_index]} is fixed")
            sort(low, pivot_index - 1)
            sort(pivot_index + 1, high)

    sort(0, len(a) - 1)

    return {
        "algorithm": "Quick Sort",
        "array": a,
        "steps": steps,
        "comparisons": comparisons,
        "swaps": swaps,
        "complexity": {"best": "O(n log n)", "average": "O(n log n)", "worst": "O(n²)", "space": "O(log n)"}
    }
