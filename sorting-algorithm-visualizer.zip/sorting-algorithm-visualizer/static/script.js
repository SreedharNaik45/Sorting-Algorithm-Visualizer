const algorithmSelect = document.getElementById("algorithm");
const arraySizeInput = document.getElementById("array-size");
const speedInput = document.getElementById("speed");
const speedLabel = document.getElementById("speed-label");
const customArrayInput = document.getElementById("custom-array");
const bars = document.getElementById("bars");
const operation = document.getElementById("operation");
const statusBadge = document.getElementById("status-badge");
const errorBox = document.getElementById("error");

const comparisonsEl = document.getElementById("comparisons");
const swapsEl = document.getElementById("swaps");
const stepsEl = document.getElementById("steps");
const arrayCountEl = document.getElementById("array-count");

const descriptionEl = document.getElementById("description");
const bestEl = document.getElementById("best");
const averageEl = document.getElementById("average");
const worstEl = document.getElementById("worst");
const spaceEl = document.getElementById("space");
const stableEl = document.getElementById("stable");
const inPlaceEl = document.getElementById("in-place");
const visualTitle = document.getElementById("visual-title");

const generateBtn = document.getElementById("generate-btn");
const applyBtn = document.getElementById("apply-btn");
const startBtn = document.getElementById("start-btn");
const pauseBtn = document.getElementById("pause-btn");
const stepBtn = document.getElementById("step-btn");
const resetBtn = document.getElementById("reset-btn");

let array = [];
let originalArray = [];
let steps = [];
let currentStep = 0;
let isRunning = false;
let isPaused = false;
let runToken = 0;
let algorithmInfo = [];

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

function showError(message = "") {
    errorBox.textContent = message;
}

function setStatus(text) {
    statusBadge.textContent = text;
}

function generateRandomArray() {
    stopAnimation();
    showError();

    const size = Math.max(5, Math.min(80, Number(arraySizeInput.value) || 30));
    arraySizeInput.value = size;

    array = Array.from({ length: size }, () => Math.floor(Math.random() * 90) + 10);
    originalArray = [...array];

    resetStats();
    renderBars();
    updateAlgorithmInfo();
    operation.textContent = "Random array generated. Ready.";
    setStatus("Ready");
}

function parseCustomArray() {
    const raw = customArrayInput.value.trim();
    if (!raw) throw new Error("Enter an array such as: 9, 4, 7, 1, 3.");

    const values = raw.split(/[\s,]+/).filter(Boolean).map(Number);

    if (values.length < 1 || values.length > 80 || values.some(v => !Number.isInteger(v))) {
        throw new Error("Enter 1–80 integer values separated by commas or spaces.");
    }

    if (values.some(v => Math.abs(v) > 999)) {
        throw new Error("Values must be between -999 and 999.");
    }

    return values;
}

function useCustomArray() {
    try {
        stopAnimation();
        array = parseCustomArray();
        originalArray = [...array];
        arraySizeInput.value = array.length;
        resetStats();
        renderBars();
        operation.textContent = "Custom array loaded. Ready.";
        setStatus("Ready");
        showError();
    } catch (error) {
        showError(error.message);
    }
}

function resetStats() {
    comparisonsEl.textContent = "0";
    swapsEl.textContent = "0";
    stepsEl.textContent = "0 / 0";
    arrayCountEl.textContent = array.length;
}

function renderBars(activeIndices = [], sortedFrom = null) {
    bars.innerHTML = "";

    if (!array.length) return;

    const min = Math.min(...array);
    const max = Math.max(...array);
    const range = Math.max(1, max - min);

    array.forEach((value, index) => {
        const bar = document.createElement("div");
        bar.className = "bar";

        // Keep negative values visually usable by mapping the minimum to a small height.
        const normalized = max === min ? 0.55 : 0.15 + ((value - min) / range) * 0.85;
        bar.style.height = `${normalized * 320}px`;

        if (activeIndices.includes(index)) bar.classList.add("active");
        if (sortedFrom !== null && index >= sortedFrom) bar.classList.add("sorted");

        const label = document.createElement("span");
        label.className = "bar-value";
        label.textContent = value;
        bar.appendChild(label);

        bars.appendChild(bar);
    });
}

function updateAlgorithmInfo() {
    const info = algorithmInfo.find(item => item.id === algorithmSelect.value);
    if (!info) return;

    visualTitle.textContent = info.name;
    descriptionEl.textContent = info.description;
    bestEl.textContent = info.best;
    averageEl.textContent = info.average;
    worstEl.textContent = info.worst;
    spaceEl.textContent = info.space;
    stableEl.textContent = info.stable ? "Yes" : "No";
    inPlaceEl.textContent = info.in_place ? "Yes" : "No";
}

function updateSpeedLabel() {
    speedLabel.textContent = `${speedInput.value} ms`;
}

function stopAnimation() {
    runToken++;
    isRunning = false;
    isPaused = false;
    pauseBtn.disabled = true;
    pauseBtn.textContent = "Pause";
    stepBtn.disabled = true;
    startBtn.disabled = false;
    setStatus("Ready");
}

function applyStep(step) {
    array = [...step.array];
    const active = Array.isArray(step.indices) ? step.indices : [];

    renderBars(active);
    operation.textContent = step.message || "Processing...";
    currentStep++;
    stepsEl.textContent = `${currentStep} / ${steps.length}`;
}

async function startSorting() {
    if (isRunning) return;

    showError();
    if (!array.length) {
        showError("Generate or enter an array first.");
        return;
    }

    startBtn.disabled = true;
    pauseBtn.disabled = true;
    stepBtn.disabled = true;
    setStatus("Preparing...");

    try {
        const response = await fetch("/api/sort", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                algorithm: algorithmSelect.value,
                array
            })
        });

        const result = await response.json();

        if (!response.ok) throw new Error(result.error || "Sorting request failed.");

        steps = result.steps;
        currentStep = 0;
        comparisonsEl.textContent = result.comparisons;
        swapsEl.textContent = result.swaps;
        stepsEl.textContent = `0 / ${steps.length}`;

        isRunning = true;
        isPaused = false;
        pauseBtn.disabled = false;
        stepBtn.disabled = false;
        pauseBtn.textContent = "Pause";
        setStatus("Running");

        const token = ++runToken;

        for (const step of steps) {
            if (token !== runToken) return;

            while (isPaused) {
                await sleep(40);
                if (token !== runToken) return;
            }

            applyStep(step);
            await sleep(Number(speedInput.value));

            if (token !== runToken) return;
        }

        array = [...result.array];
        renderBars([], 0);
        currentStep = steps.length;
        stepsEl.textContent = `${steps.length} / ${steps.length}`;
        operation.textContent = "Sorting complete.";
        setStatus("Sorted");
        isRunning = false;
        pauseBtn.disabled = true;
        stepBtn.disabled = true;
        startBtn.disabled = false;

    } catch (error) {
        isRunning = false;
        pauseBtn.disabled = true;
        stepBtn.disabled = true;
        startBtn.disabled = false;
        setStatus("Error");
        showError(error.message);
    }
}

function togglePause() {
    if (!isRunning) return;

    isPaused = !isPaused;
    pauseBtn.textContent = isPaused ? "Resume" : "Pause";
    setStatus(isPaused ? "Paused" : "Running");
}

function stepOnce() {
    if (!isRunning || !isPaused || currentStep >= steps.length) return;

    applyStep(steps[currentStep]);

    if (currentStep >= steps.length) {
        array = [...steps[steps.length - 1].array];
        renderBars([], 0);
        operation.textContent = "Sorting complete.";
        setStatus("Sorted");
        isRunning = false;
        isPaused = false;
        pauseBtn.disabled = true;
        stepBtn.disabled = true;
        startBtn.disabled = false;
    }
}

function resetArray() {
    stopAnimation();
    array = [...originalArray];
    currentStep = 0;
    steps = [];
    resetStats();
    renderBars();
    operation.textContent = "Reset to the original array.";
    setStatus("Ready");
    showError();
}

async function loadAlgorithmInfo() {
    try {
        const response = await fetch("/api/algorithms");
        algorithmInfo = await response.json();
        updateAlgorithmInfo();
    } catch {
        showError("Could not load algorithm information.");
    }
}

algorithmSelect.addEventListener("change", () => {
    updateAlgorithmInfo();
    if (!isRunning) operation.textContent = "Algorithm changed. Ready.";
});

speedInput.addEventListener("input", updateSpeedLabel);
generateBtn.addEventListener("click", generateRandomArray);
applyBtn.addEventListener("click", useCustomArray);
startBtn.addEventListener("click", startSorting);
pauseBtn.addEventListener("click", togglePause);
stepBtn.addEventListener("click", stepOnce);
resetBtn.addEventListener("click", resetArray);

generateRandomArray();
updateSpeedLabel();
loadAlgorithmInfo();
