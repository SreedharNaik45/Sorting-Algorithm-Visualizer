def heap_sort(arr):
    steps = []
    comparisons = 0
    swaps = 0
    a = arr.copy()

    def record(kind, indices, message):
        steps.append({
            "type": kind,
            "indices": indices,
            "array": a.copy(),
            "message": message
        })

    def heapify(n, i):
        nonlocal comparisons, swaps
        largest = i
        left = 2 * i + 1
        right = 2 * i + 2

        if left < n:
            comparisons += 1
            record("compare", [largest, left], f"Compare {a[largest]} and {a[left]}")
            if a[left] > a[largest]:
                largest = left

        if right < n:
            comparisons += 1
            record("compare", [largest, right], f"Compare {a[largest]} and {a[right]}")
            if a[right] > a[largest]:
                largest = right

        if largest != i:
            a[i], a[largest] = a[largest], a[i]
            swaps += 1
            record("swap", [i, largest], f"Swap {a[i]} and {a[largest]}")
            heapify(n, largest)

    n = len(a)

    for i in range(n // 2 - 1, -1, -1):
        heapify(n, i)

    for end in range(n - 1, 0, -1):
        a[0], a[end] = a[end], a[0]
        swaps += 1
        record("swap", [0, end], f"Move maximum {a[end]} to final position")
        heapify(end, 0)

    return {
        "algorithm": "Heap Sort",
        "array": a,
        "steps": steps,
        "comparisons": comparisons,
        "swaps": swaps,
        "complexity": {"best": "O(n log n)", "average": "O(n log n)", "worst": "O(n log n)", "space": "O(1)"}
    }
