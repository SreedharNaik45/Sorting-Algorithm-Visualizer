# Sorting Algorithm Visualizer

An interactive web application that demonstrates how common sorting algorithms work by visualizing comparisons, swaps, writes, and final placement step by step.

The project is designed as both a **DSA learning tool** and a **portfolio-ready Python project**.

## Features

- Interactive visualization using vertical bars
- Random array generation
- Custom array input
- Six sorting algorithms
- Adjustable animation speed
- Pause / resume
- Step-by-step execution
- Reset to the original array
- Comparison counter
- Swap/write counter
- Step counter
- Time and space complexity
- Stability and in-place information
- Responsive layout
- Clean separation between sorting algorithms and web interface

## Algorithms

| Algorithm | Best | Average | Worst | Space | Stable | In-place |
|---|---|---|---|---|---|---|
| Bubble Sort | O(n) | O(n²) | O(n²) | O(1) | Yes | Yes |
| Selection Sort | O(n²) | O(n²) | O(n²) | O(1) | No | Yes |
| Insertion Sort | O(n) | O(n²) | O(n²) | O(1) | Yes | Yes |
| Merge Sort | O(n log n) | O(n log n) | O(n log n) | O(n) | Yes | No |
| Quick Sort | O(n log n) | O(n log n) | O(n²) | O(log n) | No | Yes |
| Heap Sort | O(n log n) | O(n log n) | O(n log n) | O(1) | No | Yes |

> Complexity shown for Quick Sort assumes the recursive stack with the chosen last-element pivot implementation. The worst case can use O(n) recursion depth.

## How it works

The sorting functions do not simply return a sorted array. They also produce a sequence of visualization **steps**.

Each step contains:

```text
type
indices
array state
message
```

For example:

```json
{
  "type": "compare",
  "indices": [2, 3],
  "array": [5, 2, 7, 1],
  "message": "Compare 7 and 1"
}
```

The Flask backend sends these steps to the browser. JavaScript then plays them one by one.

### Architecture

```text
User
 |
 v
HTML/CSS/JavaScript
 |
 | POST /api/sort
 v
Flask API
 |
 v
Sorting Algorithm
 |
 v
Step Generator
 |
 v
JSON response
 |
 v
JavaScript Animation
 |
 v
Interactive Visualization
```

## Project Structure

```text
sorting-algorithm-visualizer/
│
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
│
├── algorithms/
│   ├── __init__.py
│   ├── bubble_sort.py
│   ├── selection_sort.py
│   ├── insertion_sort.py
│   ├── merge_sort.py
│   ├── quick_sort.py
│   └── heap_sort.py
│
├── templates/
│   └── index.html
│
└── static/
    ├── style.css
    └── script.js
```

## Installation

### 1. Clone the repository

```bash
git clone https://github.com/YOUR_USERNAME/sorting-algorithm-visualizer.git
cd sorting-algorithm-visualizer
```

### 2. Create a virtual environment

Windows:

```bash
python -m venv .venv
.venv\Scripts\activate
```

macOS / Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Run the application

```bash
python app.py
```

Open:

```text
http://127.0.0.1:5000
```

## How to use

1. Select an algorithm.
2. Generate a random array or enter a custom array.
3. Choose an animation speed.
4. Press **Start**.
5. Use **Pause** to stop the animation.
6. Use **Step** while paused to inspect individual operations.
7. Press **Reset** to restore the original array.

## Learning objectives

This project demonstrates:

- Arrays
- Iteration
- Recursion
- Divide and conquer
- Partitioning
- Heap data structure
- Sorting algorithms
- Time complexity
- Space complexity
- Stable vs. unstable sorting
- In-place algorithms
- Python modules
- Flask REST endpoints
- JSON data exchange
- JavaScript DOM manipulation
- Asynchronous animation

## Future improvements

Possible extensions:

- Counting Sort
- Radix Sort
- Shell Sort
- Algorithm comparison mode
- Execution-time benchmarking
- Array-size performance graphs
- Dark mode
- Search/filter for algorithms
- Export visualization statistics
- Educational pseudocode panel
- Code panel showing the current algorithm
- Deployment using a production WSGI server

## License

This project is intended for educational and portfolio use.
