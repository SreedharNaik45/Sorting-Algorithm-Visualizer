def merge_sort(arr):
    steps = []
    comparisons = 0
    writes = 0
    a = arr.copy()

    def record(kind, indices, message):
        steps.append({
            "type": kind,
            "indices": indices,
            "array": a.copy(),
            "message": message
        })

    def merge(left, mid, right):
        nonlocal comparisons, writes
        left_part = a[left:mid + 1]
        right_part = a[mid + 1:right + 1]
        i = j = 0
        k = left

        while i < len(left_part) and j < len(right_part):
            comparisons += 1
            record("compare", [left + i, mid + 1 + j],
                   f"Compare {left_part[i]} and {right_part[j]}")

            if left_part[i] <= right_part[j]:
                a[k] = left_part[i]
                i += 1
            else:
                a[k] = right_part[j]
                j += 1

            writes += 1
            record("write", [k], f"Write {a[k]} at index {k}")
            k += 1

        while i < len(left_part):
            a[k] = left_part[i]
            i += 1
            writes += 1
            record("write", [k], f"Write {a[k]} at index {k}")
            k += 1

        while j < len(right_part):
            a[k] = right_part[j]
            j += 1
            writes += 1
            record("write", [k], f"Write {a[k]} at index {k}")
            k += 1

    def divide(left, right):
        if left >= right:
            return
        mid = (left + right) // 2
        divide(left, mid)
        divide(mid + 1, right)
        merge(left, mid, right)

    divide(0, len(a) - 1)

    return {
        "algorithm": "Merge Sort",
        "array": a,
        "steps": steps,
        "comparisons": comparisons,
        "swaps": writes,
        "complexity": {"best": "O(n log n)", "average": "O(n log n)", "worst": "O(n log n)", "space": "O(n)"}
    }
