def insertion_sort(arr):
    steps = []
    comparisons = 0
    shifts = 0
    a = arr.copy()

    def record(kind, indices, message):
        steps.append({
            "type": kind,
            "indices": indices,
            "array": a.copy(),
            "message": message
        })

    for i in range(1, len(a)):
        key = a[i]
        j = i - 1

        while j >= 0:
            comparisons += 1
            record("compare", [j, j + 1], f"Compare {a[j]} with key {key}")
            if a[j] > key:
                a[j + 1] = a[j]
                shifts += 1
                record("shift", [j, j + 1], f"Shift {a[j]} to the right")
                j -= 1
            else:
                break

        a[j + 1] = key
        record("insert", [j + 1], f"Insert {key} at index {j + 1}")

    return {
        "algorithm": "Insertion Sort",
        "array": a,
        "steps": steps,
        "comparisons": comparisons,
        "swaps": shifts,
        "complexity": {"best": "O(n)", "average": "O(n²)", "worst": "O(n²)", "space": "O(1)"}
    }
