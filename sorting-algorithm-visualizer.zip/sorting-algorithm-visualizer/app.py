from flask import Flask, jsonify, render_template, request

from algorithms.bubble_sort import bubble_sort
from algorithms.selection_sort import selection_sort
from algorithms.insertion_sort import insertion_sort
from algorithms.merge_sort import merge_sort
from algorithms.quick_sort import quick_sort
from algorithms.heap_sort import heap_sort

app = Flask(__name__)

ALGORITHMS = {
    "bubble": bubble_sort,
    "selection": selection_sort,
    "insertion": insertion_sort,
    "merge": merge_sort,
    "quick": quick_sort,
    "heap": heap_sort,
}


@app.route("/")
def index():
    return render_template("index.html")


@app.post("/api/sort")
def sort_array():
    data = request.get_json(silent=True) or {}
    algorithm_name = data.get("algorithm", "bubble")
    raw_array = data.get("array", [])

    if algorithm_name not in ALGORITHMS:
        return jsonify({"error": "Unknown sorting algorithm."}), 400

    if not isinstance(raw_array, list):
        return jsonify({"error": "Array must be a list of numbers."}), 400

    if not raw_array or len(raw_array) > 80:
        return jsonify({"error": "Array size must be between 1 and 80."}), 400

    try:
        array = [int(value) for value in raw_array]
    except (TypeError, ValueError):
        return jsonify({"error": "All array values must be integers."}), 400

    if any(abs(value) > 999 for value in array):
        return jsonify({"error": "Values must be between -999 and 999."}), 400

    result = ALGORITHMS[algorithm_name](array)
    return jsonify(result)


@app.get("/api/algorithms")
def algorithms():
    return jsonify([
        {
            "id": "bubble",
            "name": "Bubble Sort",
            "best": "O(n)",
            "average": "O(n²)",
            "worst": "O(n²)",
            "space": "O(1)",
            "stable": True,
            "in_place": True,
            "description": "Repeatedly compares adjacent elements and swaps them when they are in the wrong order."
        },
        {
            "id": "selection",
            "name": "Selection Sort",
            "best": "O(n²)",
            "average": "O(n²)",
            "worst": "O(n²)",
            "space": "O(1)",
            "stable": False,
            "in_place": True,
            "description": "Finds the smallest remaining element and places it at the next sorted position."
        },
        {
            "id": "insertion",
            "name": "Insertion Sort",
            "best": "O(n)",
            "average": "O(n²)",
            "worst": "O(n²)",
            "space": "O(1)",
            "stable": True,
            "in_place": True,
            "description": "Builds the sorted portion one element at a time by inserting each value into its correct position."
        },
        {
            "id": "merge",
            "name": "Merge Sort",
            "best": "O(n log n)",
            "average": "O(n log n)",
            "worst": "O(n log n)",
            "space": "O(n)",
            "stable": True,
            "in_place": False,
            "description": "Divides the array into halves, recursively sorts them, and merges the sorted halves."
        },
        {
            "id": "quick",
            "name": "Quick Sort",
            "best": "O(n log n)",
            "average": "O(n log n)",
            "worst": "O(n²)",
            "space": "O(log n)",
            "stable": False,
            "in_place": True,
            "description": "Partitions the array around a pivot and recursively sorts the partitions."
        },
        {
            "id": "heap",
            "name": "Heap Sort",
            "best": "O(n log n)",
            "average": "O(n log n)",
            "worst": "O(n log n)",
            "space": "O(1)",
            "stable": False,
            "in_place": True,
            "description": "Builds a max heap and repeatedly moves the largest element to the end."
        },
    ])


if __name__ == "__main__":
    app.run(debug=True)
