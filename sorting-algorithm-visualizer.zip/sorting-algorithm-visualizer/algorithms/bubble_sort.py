def bubble_sort(arr):
    steps = []
    comparisons = 0
    swaps = 0
    a = arr.copy()

    def record(kind, indices, message):
        steps.append({
            "type": kind,
            "indices": indices,
            "array": a.copy(),
            "message": message
        })

    n = len(a)
    for i in range(n - 1):
        swapped = False
        for j in range(n - i - 1):
            comparisons += 1
            record("compare", [j, j + 1], f"Compare {a[j]} and {a[j + 1]}")
            if a[j] > a[j + 1]:
                a[j], a[j + 1] = a[j + 1], a[j]
                swaps += 1
                swapped = True
                record("swap", [j, j + 1], f"Swap {a[j + 1]} and {a[j]}")
        if not swapped:
            break

    return {
        "algorithm": "Bubble Sort",
        "array": a,
        "steps": steps,
        "comparisons": comparisons,
        "swaps": swaps,
        "complexity": {"best": "O(n)", "average": "O(n²)", "worst": "O(n²)", "space": "O(1)"}
    }
