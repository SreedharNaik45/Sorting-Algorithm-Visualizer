# Project Report: Interactive Visualization of Sorting Algorithms

## 1. Introduction

Sorting is one of the fundamental operations in computer science and is widely used in searching, data processing, databases, and many other applications. Although sorting algorithms can be described mathematically, their behavior is easier to understand when their individual operations are visible.

This project develops an interactive Sorting Algorithm Visualizer. It represents array values as vertical bars and animates comparisons, swaps, shifts, writes, and pivot operations.

## 2. Problem Statement

Students often learn sorting algorithms from pseudocode and static examples. This can make it difficult to understand how the array changes during each operation.

The objective of this project is to create an interactive application that makes the internal behavior of common sorting algorithms visible and measurable.

## 3. Objectives

- Implement common sorting algorithms in Python.
- Visualize the intermediate states of an array.
- Display comparisons and swaps/writes.
- Allow users to control animation speed.
- Support custom arrays.
- Provide complexity and algorithm properties.
- Build a clean web interface suitable for learning and demonstration.

## 4. Technologies

- Python
- Flask
- HTML5
- CSS3
- JavaScript
- JSON
- Git/GitHub

## 5. Algorithms Implemented

### Bubble Sort
Compares adjacent elements and swaps them if they are in the wrong order.

### Selection Sort
Selects the smallest element from the unsorted portion and places it at the next sorted position.

### Insertion Sort
Maintains a sorted prefix and inserts each new element into its correct location.

### Merge Sort
Uses divide and conquer by recursively splitting the array and merging sorted subarrays.

### Quick Sort
Chooses a pivot, partitions the array around it, and recursively sorts the resulting partitions.

### Heap Sort
Builds a max heap and repeatedly moves the maximum element to the end of the array.

## 6. System Design

The system has three major layers:

1. **Presentation layer** — HTML/CSS/JavaScript.
2. **API layer** — Flask.
3. **Algorithm layer** — independent Python modules.

The algorithms produce a list of visualization steps rather than only returning the final sorted array.

## 7. Advantages

- Easy to understand visually.
- Useful for DSA learning.
- Supports multiple algorithms.
- Provides measurable operation counts.
- Modular code structure.
- Can be extended with additional algorithms.

## 8. Limitations

- The visualizer limits array size so that animations remain readable.
- Operation counts are educational metrics and depend on the implementation details.
- The application is intended for learning rather than high-performance benchmarking.

## 9. Future Scope

The project can be extended with more sorting algorithms, benchmarking graphs, pseudocode highlighting, code visualization, dark mode, user accounts, and deployment as a public web application.

## 10. Conclusion

The project demonstrates how algorithm implementation and interactive visualization can be combined to make sorting algorithms easier to understand. It also provides practical experience with Python, Flask, JavaScript, APIs, modular design, and GitHub project organization.
