def selection_sort(arr):
    steps = []
    comparisons = 0
    swaps = 0
    a = arr.copy()

    def record(kind, indices, message):
        steps.append({
            "type": kind,
            "indices": indices,
            "array": a.copy(),
            "message": message
        })

    n = len(a)
    for i in range(n - 1):
        min_index = i
        for j in range(i + 1, n):
            comparisons += 1
            record("compare", [min_index, j], f"Compare {a[min_index]} and {a[j]}")
            if a[j] < a[min_index]:
                min_index = j
        if min_index != i:
            old_i, old_min = a[i], a[min_index]
            a[i], a[min_index] = a[min_index], a[i]
            swaps += 1
            record("swap", [i, min_index], f"Place {old_min} before {old_i}")

    return {
        "algorithm": "Selection Sort",
        "array": a,
        "steps": steps,
        "comparisons": comparisons,
        "swaps": swaps,
        "complexity": {"best": "O(n²)", "average": "O(n²)", "worst": "O(n²)", "space": "O(1)"}
    }
